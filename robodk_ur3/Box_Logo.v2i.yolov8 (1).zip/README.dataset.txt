# Box_Logo > 2026-03-16 6:59pm
https://universe.roboflow.com/box-assembly-robot/box_logo-vqlio

Provided by a Roboflow user
License: CC BY 4.0

